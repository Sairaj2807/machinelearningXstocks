import yfinance as yf
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import datetime


ticker = "RELIANCE.NS" 
start_date = "2025-04-03"
end_date = datetime.datetime.today().strftime('%Y-%m-%d')


data = yf.download(ticker, start=start_date, end=end_date)
data = data[['Close']]
data['Target'] = data['Close'].shift(-1)
data.dropna(inplace=True)

X = np.array(data[['Close']])
y = np.array(data['Target'])


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

model = LinearRegression()
model.fit(X_train, y_train)


predictions = model.predict(X_test)
plt.figure(figsize=(12, 6))
plt.plot(y_test, label='Actual')
plt.plot(predictions, label='Predicted')
plt.title(f'{ticker} - Closing Price Prediction')
plt.xlabel('Days')
plt.ylabel('Price')
plt.legend()
plt.grid(True)
plt.show()

last_close = data['Close'].iloc[-1]
predicted_price = model.predict([[last_close]])[0]
print(f"Predicted next closing price for {ticker}: ${predicted_price:.2f}")
